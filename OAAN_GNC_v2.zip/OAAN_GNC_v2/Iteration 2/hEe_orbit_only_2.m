% hEe method rendezvous single run
% Version 1

SimIn.Id.Name = 'hEe_orbit_rendezvous';
SimIn.Id.Version = '2';
SimIn.OrbMatch.EOM_IC.r0_t = r0_t;
SimIn.OrbMatch.EOM_IC.r0_f = r0_f;
SimIn.OrbMatch.EOM_IC.v0_t = v0_t;
SimIn.OrbMatch.EOM_IC.v0_f = v0_f;
SimIn.Resources.dV_used = 0;

% Initialize recording matrices
Tvec = [];
PosI_T = [];
VelI_T = [];
PosI_F = [];
VelI_F = [];
els_T = [];
els_F = [];
x_T = [];
x_F = [];
Thrust_F = [];
dV_F = [];
abs_sep_orbMatch = [];

x_f_current=x0_f;
x_t_current=x0_t;
dV_tot=0;

%% Orbit Matching Phase

x_target = x0_t;

while(~orb_matched(x_f_current,x_t_current,K_F,match_tol))
% while (i<=10)
%     i=i+1;
    
    sim('hEe_orbit_rendezvous_2_orbMatch.slx',man_time)
    
    if (isempty(Tvec))
        Tvec = [Tvec;dummy.time];
    else
        Tvec = [Tvec;dummy.time+Tvec(end)];
    end
    
    PosI_T = [PosI_T squeeze(position_t.signals.values)'];
    VelI_T = [VelI_T squeeze(velocity_t.signals.values)'];
    PosI_F = [PosI_F squeeze(position_f.signals.values)'];
    VelI_F = [VelI_F squeeze(velocity_f.signals.values)'];
    els_T = [els_T;squeeze(els_t.signals.values)];
    els_F = [els_F;squeeze(els_f.signals.values)];
    x_T = [x_T squeeze(x_t.signals.values)'];
    x_F = [x_F squeeze(x_f.signals.values)'];
    Thrust_F = [Thrust_F squeeze(thrust_f.signals.values)'];
    dV_F = [dV_F squeeze(dV_f.signals.values)'];
    dV_tot = dV_F(end);
    abs_sep_orbMatch = [abs_sep_orbMatch;squeeze(abs_dist.signals.values)];
    
    x_t_current = x_T(:,end);
    x_f_current = x_F(:,end);
    SimIn.OrbMatch.EOM_IC.r0_t = PosI_T(:,end);
    SimIn.OrbMatch.EOM_IC.v0_t = VelI_T(:,end);
    SimIn.OrbMatch.EOM_IC.r0_f = PosI_F(:,end);
    SimIn.OrbMatch.EOM_IC.v0_f = VelI_F(:,end);
    SimIn.Resources.dV_used = dV_F(end);
end

fprintf('Orbit matching complete\n');
