% hEe method rendezvous Master Script
% Version 1
% Matt Walsh

clear
close all
clc

% global constants
RE = 6378137; % radius of earth in m
muE = 3.98600441500E+14; % gravitational parameter of earth m^3/s^2
J2 = 1.08263566655E-03; % oblateness constant

%% Initialization

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Control                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Flag for running Monte Carlo, set to SimType.single_run for a single run,
% set to SimType.monte_carlo for monte carlo analysis
simtype = SimType.single_run;

% Number of Monte Carlo runs (will only activate if monte_carlo = 1)
NMC = 5;

% Orbit specification type, set to OrbitSpec.elements to specify orbital
% elements, OrbitSpec.rv to specify position and velocity vectors,
% OrbitSpec.xtheta to specify x and true anomaly
orbspec_l=OrbitSpec.elements;
orbspec_f=OrbitSpec.elements;
orbspec_t=OrbitSpec.elements;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameter Specification                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% System Properties
% spacecraft mass in kg
m_leader = 5;
m_follower = 5;

% Inertia matrix in kg*m^2 (placeholder)
I=[1 0 0
   0 1 0
   0 0 1];
invI=inv(I);

% maximum deltaV budget in m/s
dV_max = 10;

% hardware limits
% subsystems not fully implemented so parameters given are placeholders

% impulse per pulse range for thrusters in Nms
Imp_range=[.000 5];

% Maximum thrust
Thrust_max=1; % N

% saturation of the reaction wheels in Nms (placeholder)
wmax_1 = 100;
wmax_2 = 100;
wmax_3 = 100;
wmax_4 = 100;

% maximum acceleration of reaction wheels in Nm (placeholder)
accelmax=10;        

% Wheel Jacobian
Iwi=100;
A=1/3*[2 -1 2;2 2 -1;-1 2 2]*Iwi;
pinvA=pinv(A);

% gains for ACS subsystem (placeholder values)
Kp = 1;
Kd = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time parameters                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T_maneuver=1; % on time for a single manuever
t_update=1200; % seconds between th_opt updates
t_wait=7200; % initial wait time - time after activation maneuvers begin
man_time=3600; % length of maneuver calculation and execution cycle (s)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Tolerances                                                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

match_tol = 0.5; % tolerance for weighted matching of orbits

% Distance for close-proximity rendezvous
d_close=2000; % m; distance between spacecraft for rendezvous

% Tolerances for true anomaly calculation
circTol=1e-9; % tolerance for circular orbit
incTol=1e-6;  % tolerance for equatorial orbit

%% Orbit Specification

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Orbital Elements                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% input leader orbit parameters
a0_l=RE+400000; % semimajor axis
e0_l=0.000; % eccentricity
% e0_l=20000/(2*(RE+410000));  
i0_l=0; % inclination
w0_l=0; % argument of periapsis
Om0_l=pi/2; % longitude of ascending node
th0_l=0; % true anomaly

% input follower orbit parameters
a0_f=RE+414800; % semimajor axis
e0_f=20000/(2*(RE+415000))+.0001;         % eccentricity
% e0_f=0.000;
i0_f=51.65*pi/180-.0001;         % inclination
w0_f=pi/6+.00005; 
Om0_f=0-.00007;
th0_f=0;

% input target orbit parameters
a0_t=RE+415500; % semimajor axis
% e0_t=0.000; % eccentricity
e0_t=20000/(2*(RE+415000))-.0001;  
i0_t=51.65*pi/180+.0001; % inclination
w0_t=pi/6+.00002; % argument of periapsis
Om0_t=0+.00001; % longitude of ascending node
th0_t=0; % true anomaly

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% position and velocity vectors                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% follower
r0_f=[0;0;0];
v0_f=[0;0;0];

% leader
r0_l=[0;0;0];
v0_l=[0;0;0];

% target
r0_t=[0;0;0];
v0_t=[0;0;0];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% x and true anomaly                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% follower
x0_f=[0;0;0;0;0;0;0];
th0_f=0;

% leader
x0_l=[0;0;0;0;0;0;0];
th0_l=0;

% target
x0_t=[0;0;0;0;0;0;0];
th0_t=0;

%% Simulation setup and drift phase

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% orbit setup for sim                                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% leader
if (orbspec_l == OrbitSpec.xtheta)
    h0_l=x0_l(1:3);
    E0_l=x0_l(4);
    e0v_l=x0_l(5:7);
    
    a0_l=-muE/(2*E0_l);
    e0_l=norm(e0v_l);
    i0_l=acos(h0_l(3)/norm(h0_l));
    
    n=cross([0;0;1],h0_l);
    Om0_l=acos(n(1)/norm(n));
    q34=n(2)<0;
    Om0_l(q34)=2*pi-Om0_l(q34);
    
    if (e0v_l(3)<0)
        w0_l=2*pi-acos(dot(n,e0v_l)/(norm(n)*norm(e0v_l)));
    else
        w0_l=acos(dot(n,e0v_l)/(norm(n)*norm(e0v_l)));
    end
elseif (orbspec_l ~= OrbitSpec.rv)
    [r0_l,v0_l]=orb2rv_s(a0_l*(1-e0_l^2),e0_l,i0_l,Om0_l,w0_l,th0_l,muE);
end

if (orbspec_l ~= OrbitSpec.xtheta)
    R0_l=norm(r0_l);
    V0_l=norm(v0_l);
    h_l=cross(r0_l,v0_l);
    E_l=V0_l^2/2-muE/R0_l;
    e_l=cross(v0_l,h_l)/muE - r0_l/R0_l;
    x_0l=[h_l;E_l;e_l];
end

% follower
if (orbspec_f == OrbitSpec.xtheta)
    h0_f=x0_f(1:3);
    E0_f=x0_f(4);
    e0v_f=x0_f(5:7);
    
    a0_f=-muE/(2*E0_f);
    e0_f=norm(e0v_f);
    i0_f=acos(h0_f(3)/norm(h0_f));
    
    n=cross([0;0;1],h0_f);
    Om0_f=acos(n(1)/norm(n));
    q34=n(2)<0;
    Om0_f(q34)=2*pi-Om0_f(q34);
    
    if (e0v_f(3)<0)
        w0_f=2*pi-acos(dot(n,e0v_f)/(norm(n)*norm(e0v_f)));
    else
        w0_f=acos(dot(n,e0v_f)/(norm(n)*norm(e0v_f)));
    end
elseif (orbspec_f ~= OrbitSpec.rv)
    [r0_f,v0_f]=orb2rv_s(a0_f*(1-e0_f^2),e0_f,i0_f,Om0_f,w0_f,th0_f,muE);
end

if (orbspec_f ~= OrbitSpec.xtheta)
    R0_f=norm(r0_f);
    V0_f=norm(v0_f);
    h_f=cross(r0_f,v0_f);
    E_f=V0_f^2/2-muE/R0_f;
    e_f=cross(v0_f,h_f)/muE - r0_f/R0_f;
    x_0f=[h_f;E_f;e_f];
end

% target
if (orbspec_t == OrbitSpec.xtheta)
    h0_t=x0_t(1:3);
    E0_t=x0_t(4);
    e0v_t=x0_t(5:7);
    
    a0_t=-muE/(2*E0_t);
    e0_t=norm(e0v_t);
    i0_t=acos(h0_t(3)/norm(h0_t));
    
    n=cross([0;0;1],h0_t);
    Om0_t=acos(n(1)/norm(n));
    q34=n(2)<0;
    Om0_t(q34)=2*pi-Om0_t(q34);
    
    if (e0v_t(3)<0)
        w0_t=2*pi-acos(dot(n,e0v_t)/(norm(n)*norm(e0v_t)));
    else
        w0_t=acos(dot(n,e0v_t)/(norm(n)*norm(e0v_t)));
    end
elseif (orbspec_t ~= OrbitSpec.rv)
    [r0_t,v0_t]=orb2rv_s(a0_t*(1-e0_t^2),e0_t,i0_t,Om0_t,w0_t,th0_t,muE);
end

if (orbspec_t ~= OrbitSpec.xtheta)
    R0_t=norm(r0_t);
    V0_t=norm(v0_t);
    h_t=cross(r0_t,v0_t);
    E_t=V0_t^2/2-muE/R0_t;
    e_t=cross(v0_t,h_t)/muE - r0_t/R0_t;
    x_0t=[h_t;E_t;e_t];
end

%% Pre simulation calculations

% Weightings for optimal thrust calculation

K_L=diag([1/norm(h_t);1/norm(h_t);1/norm(h_t);1/abs(E_t);1;1;1]);
L_L=eye(3);
K_F=K_L;
% K_F=diag([0;0;0;1;0;0;0]);
L_F=L_L;

% Assign impulse limits
Imp_min = Imp_range(1);
Imp_max = Imp_range(2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simulation                                                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (simtype == SimType.monte_carlo)
    fprintf('Monte carlo analysis\n');
%     hEe_MC_2
elseif (simtype == SimType.single_run)
    fprintf('Single run\n');
    hEe_single_2
else
    fprintf('Improper simtype specification\n')
end
