function gi = J8Gravity(pecef,a,mu,J)
%#codegen

%  J8 zonal gravitation model from the POST Formulation Manual (1990), pgs
%  4-2 and 4-3.  References for the earlier J4 model: Bate,Mueller,White,
%  _Fundamentals of Astrodynamics_, Dover 1971; pgs.421-422.  The exponents
%  for (re/r) in the J2 and J3 terms for z-dot-dot are swapped.  See also 
%  AIAA-2006-6730-282, "Gravity Modeling for Variable Fidelity Environments",
%  Michael Madden, August 2006 AIAA MST Conference.
%
%   gi = J8Grav(pecef,a,mu,J);
%
%       pecef = ECEF position vector (3x1)
%       a  = ellipsoid semi-major axis (equatorial radius)
%       mu = gravitiational constant (GM)
%       J  = column vector of zonal coefficients (J2, J3, etc).
%           Excess coefficients are ignored; missing are considered zero.
%
%       gi = gravitation using J8 model (ECEF, 3x1)
%
%   The values peci, a, mu, and gi are to be expressed in a coherent set of
%   units (i.e. the same fundamental units of time and distance should be 
%   used for all).  The J values are dimensionless.

%   2010-07-30  S.Derry
%   2012-02-13  S.Derry     J3_z correction for equatorial cases
%   2012-09-05  S.Derry     J8 formulation
%   2012-09-28  S.Derry, T.Khong	J8 Z corrections applied
%   2012-10-09  S.Derry, T.Khong	correct sign of constant in J8 X,Y term

if norm(pecef) == 0
    
gi = zeros(3,1);
    
else

jc = [J(:); zeros(7,1)];   % pad with zeros for any missing coefficients
J2 = jc(1);
J3 = jc(2);
J4 = jc(3);
J5 = jc(4);
J6 = jc(5);
J7 = jc(6);
J8 = jc(7);

p = pecef(:);
r = sqrt(sum(p.^2));	% radius magnitude
x = p(1);       % X coordinate
y = p(2);       % Y coordinate
z = p(3);       % Z coordinate

mu_r3 = mu / (r.^3);		% mu over r^3
a_r = a / r;	% a over r
z_r = z ./ r;	% z over r

J2_xy =     1 + J2*(3/2) * (a_r.^2) .* (-5*(z_r.^2) + 1);
J3_xy = J2_xy + J3*(5/2) * (a_r.^3) .* (-7*(z_r.^3) + 3*z_r );
J4_xy = J3_xy + J4*(5/8) * (a_r.^4) .* (-63*(z_r.^4) + 42*(z_r.^2) - 3);
J5_xy = J4_xy + J5*(3/8) * (a_r.^5) .* (-231*(z_r.^5) + 210*(z_r.^3) - 35*z_r);
J6_xy = J5_xy + J6/16  * (a_r.^6) .* (-3003*(z_r.^6) + 3465*(z_r.^4) - 945*(z_r.^2) + 35);
J7_xy = J6_xy + J7/16  * (a_r.^7) .* (-6435*(z_r.^7) + 9009*(z_r.^5) - 3465*(z_r.^3) + 315*z_r);
J8_xy = J7_xy + J8/128 * (a_r.^8) .* (-109395*(z_r.^8) + 180180*(z_r.^6) - 90090*(z_r.^4) + 13860*(z_r.^2) - 315);

J2_z =    z + J2*(3/2) * (a_r.^2) .*  z.*(-5*(z_r.^2) + 3);
J3_z = J2_z + J3*(1/2) * (a_r.^3) .* (z.*(-35*(z_r.^3) + 30*z_r) - 3*r);
J4_z = J3_z + J4*(5/8) * (a_r.^4) .*  z.*(-63*(z_r.^4) + 70*(z_r.^2) - 15);
J5_z = J4_z + J5/8   * (a_r.^5) .* (z.*(-693   *(z_r.^5) +    945*(z_r.^3) -    315*z_r) + 15*r);
J6_z = J5_z + J6/16  * (a_r.^6) .*  z.*(-3003  *(z_r.^6) +   4851*(z_r.^4) -   2205*(z_r.^2) + 245);
J7_z = J6_z + J7/16  * (a_r.^7) .* (z.*(-6435  *(z_r.^7) +  12012*(z_r.^5) -   6930*(z_r.^3) + 1260*z_r) - 35*r);
J8_z = J7_z + J8/128 * (a_r.^8) .*  z.*(-109395*(z_r.^8) + 231660*(z_r.^6) - 162162*(z_r.^4) + 41580*(z_r.^2) - 2835);

gi = (-mu_r3 .* [x; y; 1]) .* [J8_xy; J8_xy; J8_z];

end
    