% PAN rendezvous GNC block test Master Script
% Version 3
% Matt Walsh

clear
close all
clc

fprintf('hEe method orbital rendezvous simulation\n')

% global constants
RE = 6378137; % radius of earth in m
muE = 3.98600441500E+14; % gravitational parameter of earth m^3/s^2
J2 = 1.08263566655E-03; % oblateness constant

%% Initialization

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Control                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Flag for running Monte Carlo, set to SimType.single_run for a single run,
% set to SimType.monte_carlo for monte carlo analysis
simtype = SimType.single_run;

% Number of Monte Carlo runs (will only activate if monte_carlo = 1)
NMC = 5;

% Orbit specification type, set to OrbitSpec.elements to specify orbital
% elements, OrbitSpec.rv to specify position and velocity vectors,
% OrbitSpec.xtheta to specify x and true anomaly
orbspec_f=OrbitSpec.elements;
orbspec_t=OrbitSpec.elements;

% test case initial conditions 
ICspec = initialCond.ISS; % ISS rendezvous
% ICspec = initialCond.Hohmann400500_1; % Hohmann transfer first leg
% ICspec = initialCond.Hohmann400500_2; % Hohmann transfer second leg
% ICspec = initialCond.IncChg_p01; % .01deg inclination change
% ICspec = initialCond.ISS2; % ISS rendezvous
% ICspec = initialCond.test; % test case 1
% ICspec = initialCond.test2; % test case 2

% number of steps for optimal dV calculation
nsteps = 10000;
nsteps_dr = 1000;

% maneuver switch; set to 1
manswitch = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameter Specification                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% System Properties
% spacecraft mass in kg
m_follower = 5;

% Inertia matrix in kg*m^2 (placeholder)
I=[1 0 0
   0 1 0
   0 0 1];
invI=inv(I);

% maximum deltaV budget in m/s
dV_max = 10;

% hardware limits
% subsystems not fully implemented so parameters given are placeholders

% thrust range in N
Thrust_min=4.9e-3;
Thrust_max=5.8e-3;

% ontime range in s
ontime_min = 0.010;
ontime_max = 1;

% impulse per pulse range for thrusters in Ns
% Imp_range=[Thrust_min*ontime_min Thrust_max*ontime_max];
Imp_range = [1e-4 5];

% saturation of the reaction wheels in Nms (placeholder)
wmax_1 = 100;
wmax_2 = 100;
wmax_3 = 100;
wmax_4 = 100;

% maximum acceleration of reaction wheels in Nm (placeholder)
accelmax=10;        

% Wheel Jacobian
Iwi=100;
A=1/3*[2 -1 2;2 2 -1;-1 2 2]*Iwi;
pinvA=pinv(A);

% gains for ACS subsystem (placeholder values)
Kp = 1;
Kd = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time parameters                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T_maneuver=5; % on time for a single manuever
t_update=1200; % seconds between th_opt updates
t_wait=7200; % initial wait time - time after activation maneuvers begin
man_time=1200; % length of maneuver calculation and execution cycle (s)
t_end=3600*24*20; % time to end simulation
T_man = 1200; % time between maneuvers

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Tolerances                                                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

match_tol = 0.1; % tolerance for weighted matching of orbits

% Distance for close-proximity rendezvous
d_close=2000; % m; distance between spacecraft for rendezvous
d_target=2000; % m; distance for docking range

% Tolerances for true anomaly calculation
circTol=1e-9; % tolerance for circular orbit
incTol=1e-6;  % tolerance for equatorial orbit

% tolerances for primary orbit matching
rtols = [500;500;50];
rntol = 500;

%% Orbit Specification

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Orbital Elements                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (ICspec == 0)
    % input follower orbit parameters
    a0_f=RE+403000; % semimajor axis
    e0_f=.0005;         % eccentricity
%     e0_f=0.000;
    i0_f=51.65*pi/180;         % inclination
    w0_f=185*pi/180; 
    Om0_f=283.72*pi/180;
    th0_f=2*pi/3;

    % input target orbit parameters
    a0_t=RE+405000; % semimajor axis
%     e0_t=0.000; % eccentricity
    e0_t=4000/(2*(RE+405000));  
    i0_t=51.6403*pi/180; % inclination
    w0_t=189.1906*pi/180; % argument of periapsis
    Om0_t=283.7256*pi/180; % longitude of ascending node
    th0_t=pi/3; % true anomaly
else
    [els_t,els_f] = IC_els(ICspec);
    a0_t=els_t(1); % semimajor axis
    e0_t=els_t(2); % eccentricity
    i0_t=els_t(3); % inclination
    w0_t=els_t(4); % argument of periapsis
    Om0_t=els_t(5); % longitude of ascending node
    th0_t=els_t(6); % true anomaly
    
    a0_f=els_f(1); % semimajor axis
    e0_f=els_f(2); % eccentricity
    i0_f=els_f(3); % inclination
    w0_f=els_f(4); % argument of periapsis
    Om0_f=els_f(5); % longitude of ascending node
    th0_f=els_f(6); % true anomaly
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% position and velocity vectors                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% follower
r0_f=[0;0;0];
v0_f=[0;0;0];

% target
r0_t=[0;0;0];
v0_t=[0;0;0];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% x and true anomaly                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% follower
x0_f=[0;0;0;0;0;0;0];
th0_f=0;

% target
x0_t=[0;0;0;0;0;0;0];
th0_t=0;

%% Simulation setup and drift phase

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% orbit setup for sim                                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% follower
if (orbspec_f == OrbitSpec.xtheta)
    h0_f=x0_f(1:3);
    E0_f=x0_f(4);
    e0v_f=x0_f(5:7);
    
    a0_f=-muE/(2*E0_f);
    e0_f=norm(e0v_f);
    i0_f=acos(h0_f(3)/norm(h0_lf));
    
    n=cross([0;0;1],h0_f);
    Om0_f=acos(n(1)/norm(n));
    q34=n(2)<0;
    Om0_f(q34)=2*pi-Om0_f(q34);
    
    if (e0v_f(3)<0)
        w0_f=2*pi-acos(dot(n,e0v_f)/(norm(n)*norm(e0v_f)));
    else
        w0_f=acos(dot(n,e0v_f)/(norm(n)*norm(e0v_f)));
    end
    
    [r0_f,v0_f]=orb2rv_s(a0_f*(1-e0_f^2),e0_f,i0_f,Om0_f,w0_f,th0_f,muE);
    
elseif (orbspec_f == OrbitSpec.rv)
    h0_f=cross(r0_f,v0_f);
    E0_f=norm(v0_f)^2/2-muE/norm(r0_f);
    e0v_f=cross(v0_f,h0_f)/muE-r0_f/norm(r0_f);
    x0_f=[h0_f;E0_f;ev0_f];
    [a0_f,e0_f,i0_f,Om0_f,w0_f,th0_f]=rv2orb(r0_f,v0_f,muE);
elseif (orbspec_f == OrbitSpec.elements)
    [r0_f,v0_f]=orb2rv_s(a0_f*(1-e0_f^2),e0_f,i0_f,Om0_f,w0_f,th0_f,muE);
    h0_f=cross(r0_f,v0_f);
    E0_f=norm(v0_f)^2/2-muE/norm(r0_f);
    e0v_f=cross(v0_f,h0_f)/muE-r0_f/norm(r0_f);
    x0_f=[h0_f;E0_f;e0v_f];
else
    fprintf('Improper parameter specification\n')
end

% target
if (orbspec_t == OrbitSpec.xtheta)
    h0_t=x0_t(1:3);
    E0_t=x0_t(4);
    e0v_t=x0_t(5:7);
    
    a0_t=-muE/(2*E0_t);
    e0_t=norm(e0v_t);
    i0_t=acos(h0_t(3)/norm(h0_t));
    
    n=cross([0;0;1],h0_t);
    Om0_t=acos(n(1)/norm(n));
    q34=n(2)<0;
    Om0_t(q34)=2*pi-Om0_t(q34);
    
    if (e0v_t(3)<0)
        w0_t=2*pi-acos(dot(n,e0v_t)/(norm(n)*norm(e0v_t)));
    else
        w0_t=acos(dot(n,e0v_t)/(norm(n)*norm(e0v_t)));
    end
    
    [r0_t,v0_t]=orb2rv_s(a0_t*(1-e0_t^2),e0_t,i0_t,Om0_t,w0_t,th0_t,muE);
    
elseif (orbspec_t == OrbitSpec.rv)
    h0_t=cross(r0_t,v0_t);
    E0_t=norm(v0_t)^2/2-muE/norm(r0_t);
    e0v_t=cross(v0_t,h0_t)/muE-r0_t/norm(r0_t);
    x0_t=[h0_t;E0_t;e0_t];
    [a0_t,e0_t,i0_t,Om0_t,w0_t,th0_t]=rv2orb(r0_t,v0_t,muE);
elseif (orbspec_t == OrbitSpec.elements)
    [r0_t,v0_t]=orb2rv_s(a0_t*(1-e0_t^2),e0_t,i0_t,Om0_t,w0_t,th0_t,muE);
    h0_t=cross(r0_t,v0_t);
    E0_t=norm(v0_t)^2/2-muE/norm(r0_t);
    e0v_t=cross(v0_t,h0_t)/muE-r0_t/norm(r0_t);
    x0_t=[h0_t;E0_t;e0v_t];
else
    fprintf('Improper parameter specification\n')
end

%% Pre simulation calculations

% Weightings for optimal thrust calculation

K_F=diag([1/norm(h0_t);1/norm(h0_t);1/norm(h0_t);1/abs(E0_t);1;1;1]);
L_F=eye(3);
% K_F=diag([0;0;0;1;0;0;0]);

% Assign impulse limits
Imp_min = Imp_range(1);
Imp_max = Imp_range(2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simulation                                                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SimIn.Id.Name = 'hEe_orbit_rendezvous';
SimIn.Id.Version = '3';
SimIn.OrbMatch.EOM_IC.r0_t = r0_t;
SimIn.OrbMatch.EOM_IC.r0_f = r0_f;
SimIn.OrbMatch.EOM_IC.v0_t = v0_t;
SimIn.OrbMatch.EOM_IC.v0_f = v0_f;
SimIn.Resources.dV_used = 0;

if (simtype == SimType.monte_carlo)
    fprintf('Monte carlo analysis\n');
%     hEe_MC_3
elseif (simtype == SimType.single_run)
    fprintf('Single run\n');
%     hEe_single_3
%     hEe_orbit_only_3
%     sim('PAN_rendezvous_GNC_test2.slx',t_end)
else
    fprintf('Improper simtype specification\n')
end
