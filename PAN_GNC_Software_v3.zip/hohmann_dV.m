function [dV1,dV2,dV] = hohmann_dV(r1,r2)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
muE=3.98600441500E+14;

dV1 = sqrt(muE/r1)*(sqrt(2*r2/(r1+r2))-1);
dV2 = sqrt(muE/r2)*(1-sqrt(2*r1/(r1+r2)));
dV = dV1 + dV2;

end

