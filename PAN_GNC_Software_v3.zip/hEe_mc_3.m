% hEe method rendezvous monte carlo
% Version 2

SimIn.Id.Name = 'hEe_orbit_rendezvous';
SimIn.Id.Version = '2';
SimIn.OrbMatch.EOM_IC.r0_t = r0_t;
SimIn.OrbMatch.EOM_IC.r0_f = r0_f;
SimIn.OrbMatch.EOM_IC.v0_t = v0_t;
SimIn.OrbMatch.EOM_IC.v0_f = v0_f;
SimIn.Resources.dV_used = 0;

% Initialize recording matrices
Tvec = [];
PosI_T = [];
VelI_T = [];
PosI_F = [];
VelI_F = [];
els_T = [];
els_F = [];
x_T = [];
x_F = [];
Thrust_F = [];
dV_F = [];
abs_sep_orbMatch = [];

x_f_current=x0_f;
x_t_current=x0_t;
dV_tot=0;