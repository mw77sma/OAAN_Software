% Class for orbit specification type specification

classdef OrbitSpec
    enumeration 
        elements, rv, xtheta
    end
end