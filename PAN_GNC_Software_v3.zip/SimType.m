% Class for simulation type specification

classdef SimType
    enumeration 
        single_run, monte_carlo
    end
end