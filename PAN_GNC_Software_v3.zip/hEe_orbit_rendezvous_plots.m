% hEe method rendezvous Plots Script
% Version 1
% Matt Walsh

abs_sep=[abs_sep_orbMatch; abs_sep_phasing];
d_els_mat=els_T-els_F;

figure(1)
subplot(3,1,1)
plot(Tvec,d_els_mat(:,1))
title('Time History of Difference in Orbital Elements')
grid on
ylabel('Semimajor Axis (m)')
subplot(3,1,2)
plot(Tvec,d_els_mat(:,2))
grid on
ylabel('Eccentricity')
subplot(3,1,3)
plot(Tvec,d_els_mat(:,3)*180/pi)
grid on
xlabel('Time (s)')
ylabel('Inclination (deg)')

figure(2)
subplot(3,1,1)
plot(Tvec,d_els_mat(:,4)*180/pi)
title('Time History of Difference in Orbital Elements and Absolute Separation')
grid on
ylabel('Argument of Periapsis (deg)')
subplot(3,1,2)
plot(Tvec,d_els_mat(:,5)*180/pi)
grid on
ylabel('Longitude of the Ascending Node (deg)')
subplot(3,1,3)
plot(Tvec,abs_sep)
grid on
xlabel('Time (s)')
ylabel('Absolute Separation (m)')

figure(3)
plot(Tvec,dV_F)
grid on
xlabel('Time (s)')
ylabel('Follower \Delta V Consumed (m/s)')